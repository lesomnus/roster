# Menu overlays

Use Storybook's top-level **Menus** gallery to explore menu overlays together.
Its Docs page uses this guide directly. **Menus/Features** collects the detailed
feature cases, showing ActionMenu and ValueMenu side by side from the same data.
The component pages keep their basic API controls and specific behavior:

- **Components/ActionMenu**: basic commands and an action-driven language trigger.
- **Components/ValueMenu**: the basic selector, item dividers, empty search results
  and selected-only/empty groups.
- **Components/PrefixValueMenu**: the leading-content wrapper's basic API, with
  icon and text examples.

Shared feature examples belong under Menus rather than being repeated on one
component page. Value-only controls in a comparison affect only ValueMenu; the
capability table below identifies those differences.

`ActionMenu` runs commands or toggles checked choices in a popup beside its
trigger. `ValueMenu` selects a value, aligning its current row with the trigger's
text. `PrefixValueMenu` wraps ValueMenu with an adjacent `prefix` React node and
a shared hover background. The prefix can be text, an icon or other inert
content; `label` supplies the accessible selector name. `prefixClassName` styles
the leading slot. The old `IconValueMenu` name and `icon`/`iconClassName` props
remain as a deprecated compatibility wrapper over this same implementation.

`ValueMenu variant="section"` makes the trigger and value rows actual `Section`
buttons, using the section background, padding and radii with small gaps between
options. It supports the same icon, description and trailing slots, keyboard
navigation, alignment, scroll and async action behavior as the other variants.
Use it when the selected value should occupy a standalone resource surface.

Button-backed popup surfaces follow the trigger's corner radii, adding their
padding and border insets so the curves are concentric. The complete default
frame inset is rounded to physical screen pixels, including display scaling and
CSS zoom, so its top and side gaps render consistently. ActionMenu also snaps
its resting position to that grid; ValueMenu retains precise trigger-text
alignment. Changing display scale while a menu is open updates the frame.
Theme tokens remain the source of truth for nominal spacing. The glass backdrop
uses the same radius, and resizing the trigger updates the surface.
All MenuItem rows, including unselected, hovered, checked and focused rows,
use the outer radius minus the actual frame inset. The scrolling
viewport and fades use the same inner curve at exposed ends; ends beside a fixed
header/footer or current-value/search row stay flat. External scrollbars remain
outside this clip. An explicit `MenuSurface` style.borderRadius remains an
override, and its inner radii shrink with the actual padding/border, clamped at
zero. Standalone MenuItem retains its fallback button radius.

## Shared surface and supported features

For navigation entries, compose `MenuItemAnchor` with native link props (or a
router link adapter). It shares MenuItem's appearance, icon/trailing slots and
press feedback while retaining hrefs, modified clicks and open-in-new-tab.
Use `MenuItemLabel` inside either row for ActionMenu's text placement and
ellipsis. The owning menu supplies roles, keyboard navigation and dismissal;
these row primitives do not create a popup or header themselves.

All three use `MenuSurface` for the portal, themed foreground, translucent
background, backdrop blur, padding and frame. The surface copies the trigger's
typography instead of inheriting the host document's font. It owns its foreground
color, so a host page cannot make dark menus unreadable. Shade and dropdown
tokens are the source of truth for appearance. `--ui-menu-selected-background`
controls the resting fill of checked actions and selected ValueMenu options in
every variant, including the default current-row layout and search results. It
uses shade32 (#202020) in dark mode, retaining the previous light selection fill;
hover fills remain unchanged. ValueMenu triggers and aligned selected options
apply their hover fill immediately so replacing one with the other on opening or
closing does not flash a resting color. This also covers reselecting the current
value; ordinary hover-out transitions remain.

Unselected ValueMenu options have transparent resting backgrounds in every
variant. The section variant retains the Section surface on its trigger and
current-value overlay, while its list choices use the same selection and hover
fills as ordinary options.

ValueMenu includes the selected choice in its list by default and marks it with
`aria-selected`. Set `hideSelected` to omit it, including from search results.
The aligned current-value/search row remains visible independently of that flag;
it is outside the listbox, so the choice appears only once among accessible
options. Reselecting the same value closes the popup without calling `choose`.
PrefixValueMenu and its IconValueMenu compatibility wrapper forward the flag.

Searchable ValueMenus open with an empty, focused input. The current display
label appears as muted placeholder text; it is not inserted into or selected in
the search field. Choices remain unfiltered until typing, and each reopening
starts a fresh search. Escape or Enter without typing leaves the selection
unchanged. After editing the query, Enter chooses the first enabled match.

Value options can include `description` for a smaller second line, such as a
resource alias, and `icon` for a leading logo. Descriptions use muted 10px
monospace text. If any choice has a description, both the trigger and the list
reserve two-line content height; selecting a different choice keeps the same
control height. The selected value displays the same label, description and
icon as its option. Descriptions participate in search and matching characters
are highlighted on their own line. Optional `trailing` content is aligned on the
right. **ValueMenu → Descriptions / SearchableDescriptions** demonstrate this.

## Entrance motion

ActionMenu animates by default. Omitted `motion` or `motion={true}` uses the
shared directional reveal from the edge nearest its trigger. Above/below menus
follow their actual resolved placement, including viewport-driven flips; a menu
beside its trigger reveals from the left. Explicit directions and effects retain
their selected origin. Use `motion={false}` for an immediate popup. Reduced-motion
preferences bypass the entrance. Motion durations/easing live in the theme tokens.
The popup frame stays on its final pixel grid while its contents reveal.

## Selected-item alignment

Set `alignItemWithTrigger` on ValueMenu to overlay the **actual selected option**
on its trigger. Earlier options extend above it and later options below it,
without changing their source order or adding a duplicate current-value row.
The selected row is highlighted and focused. The trigger's painted content is
hidden only while its aligned replacement is visible; its size stays fixed.
The selected option copies the trigger's width, height, corner radius and content
insets, including Form's larger padded controls. Other choices keep their normal
menu spacing. Resizing the trigger while open updates its replacement too;
viewport constraints still take priority when the trigger cannot fit. Fit checks
use the natural content rectangle at subpixel precision and the selected row's
actual extents around its label. They do not compare an integer-rounded
scrollHeight or assume the label is exactly at half the row height, so zoom and
asymmetric padding cannot falsely trigger edge placement. Open selectors measure
resting trigger content, excluding the button's transient press scale. Client
rectangles are converted back to the popup's CSS pixel space, so CSS zoom does
not double the selected row's dimensions or incorrectly switch to edge placement
when reopening after a selection change.
The aligned value stays fully visible and stationary throughout opening. The
surface reveals upward and downward from the selected row while surrounding
items fade in. The selected row defines both opening directions; this mode
does not need a directional entrance setting. Reduced-motion preferences skip
these entrance animations.

```tsx
<ValueMenu
  label="Effort"
  value={effort}
  choose={setEffort}
  alignItemWithTrigger
  options={efforts}
/>
```

This is a positioning mode of the existing selector, not another menu family.
It reuses the same surface, rows, groups, icons, fixed header/footer, scrolling,
disabled behavior and keyboard selection. PrefixValueMenu and IconValueMenu
forward the option too. It defaults to false to preserve existing callers.

Long lists open with the selected item in view and keep a bounded viewport above
and below the trigger. Near a viewport edge, if too few rows can fit around the
selected item, the list opens beside the trigger instead. The trigger remains
visible in that case. Insets and the minimum useful row count are theme tokens.

Item alignment requires a visible selected option. Searchable menus, hidden
selected values and values missing from the supplied options retain the existing
current-value/search-row layout. This preserves the search field's position and
avoids aligning to an unrelated item. `display` can still customize the trigger;
the actual option retains its own label.

Storybook **Components/ValueMenu/ItemAligned** exposes the basic API, and
**Menus/ItemAlignment** compares both modes with long lists, groups and icons.
**Components/PrefixValueMenu/ItemAligned** demonstrates the shared prefix wrapper.
The interaction follows the selected-item alignment described by
[shadcn Select](https://ui.shadcn.com/docs/components/base/select#align-item-with-trigger).

## Shared rows and scrolling

ActionMenu and ValueMenu also render their rows with the same `MenuItem`,
`MenuIcon`, `MenuGroupLabel` and `MenuDivider` components. This includes value
triggers, current rows and search-row icons. SVG and image icons fill a shared
decorative slot sized by `--ui-icon-size-small`, including SVGs without explicit
dimensions. Row spacing uses the menu-item padding tokens; compact ValueMenu
supplies its compact spacing to the same parts. Group typography and dividers
also share one implementation.

Both menus use `MenuScrollArea`, built on ScrollArea, for their scroll viewport,
hover-only handle, proximity expansion, rail, edge fades and scrollbar clearance.
The shared `--ui-menu-scroll-max-height` token and available viewport space bound
the list. ValueMenu's default mode keeps its current/search row outside the scrolling choices.
Scrollbar keyboard input stays with the scrollbar; item navigation reveals the
focused item without moving the popup itself.

Sharing the surface does not make the interaction APIs interchangeable. Each
menu owns its placement, focus, keyboard navigation, dismissal and roles.
PrefixValueMenu supports the same choices and search behavior as ValueMenu.

| Capability                                         | ActionMenu                                    | ValueMenu                                                        |
| -------------------------------------------------- | --------------------------------------------- | ---------------------------------------------------------------- |
| Titled/untitled groups and dividers between groups | `groups`                                      | `groups`                                                         |
| Item icons                                         | `items[].icon`                                | `options[].icon` or `groups[].items[].icon`                      |
| Group-title icons                                  | —                                             | `groups[].icon`                                                  |
| Current state                                      | `items[].checked`                             | `value` and `choose`                                             |
| Hide selected choice                               | —                                             | `hideSelected` (off by default)                                  |
| Disabled items                                     | `items[].disabled`                            | `options[].disabled`                                             |
| Wait for successful handler completion             | `awaitAction` for `run`                       | `awaitAction` for `choose`                                       |
| Disabled trigger with explanation                  | `disabled`, `disabledReason`                  | `disabled`, `disabledReason`                                     |
| Shortcut keycaps                                   | `items[].shortcut`                            | —                                                                |
| Dangerous actions and status footer                | `items[].danger`, `status`                    | —                                                                |
| Text search and search aliases                     | —                                             | `searchable`, `searchText`                                       |
| Divider before an individual item                  | —                                             | `separatorBefore`                                                |
| Muted/default value                                | —                                             | `muted` on the selector or option                                |
| Long lists                                         | Shared MenuScrollArea                         | Shared MenuScrollArea with a stationary current row              |
| Placement                                          | `placement`, `position`, `gap`                | Current-row or `alignItemWithTrigger`, automatic viewport bounds |
| Entrance animation                                 | Optional `motion`, direction and slide/reveal | Built in                                                         |
| Custom trigger                                     | `triggerContent`                              | `display`, compact variant, PrefixValueMenu                      |
| Arrow keys, Home/End, Escape and outside dismissal | Yes                                           | Yes                                                              |
| Open-native-dialog portal and themed typography    | Shared MenuSurface                            | Shared MenuSurface                                               |

Groups replace the flat item list when supplied. Both menus use
`{ label, items }` groups. Icons are caller-supplied React nodes; use decorative
SVGs with `aria-hidden="true"`. Shortcut keycaps display a binding, while the
host application implements the actual shortcut.

Enable `awaitAction` to keep either menu open during a request. Return its Promise
from `run` or `choose`; throwing or rejecting keeps the menu open and anchors the
shared ActionError to the chosen row. The active row shows pending feedback and
duplicate actions are blocked. Success closes the menu. The default remains
immediate closing. PrefixValueMenu forwards the option too. See
Menus/Features/AwaitAction and [handler failures](./handler-failures.md) for recovery
and manual-dismissal behavior.

For example, ActionMenu already supports grouped commands with icons and
individually disabled items:

```tsx
<ActionMenu
  label="Actions"
  groups={[
    {
      label: "Session",
      items: [
        { label: "Restart", icon: <RestartIcon />, run: restart },
        { label: "Stop", icon: <StopIcon />, danger: true, run: stop },
      ],
    },
    {
      label: "Workspace",
      items: [
        {
          label: "Terminal",
          icon: <TerminalIcon />,
          shortcut: ["Ctrl", "`"],
          disabled: !connected,
          run: openTerminal,
        },
      ],
    },
  ]}
/>
```

The example's icons and action handlers come from the consuming application.

## Gallery

- **Overview** compares both menus using the same surface and trigger font.
- **Groups And Icons** shows titled groups, item icons and value-group icons.
- **States And Shortcuts** shows checked choices, disabled/default states,
  dangerous actions, shortcut keycaps and a status footer.
- **Search And Scrolling** compares long action lists with searchable value
  groups, per-item dividers and the stationary current row.
- **Placement And Motion** shows above/below/beside/custom placement and
  directional slide/reveal entrances.
- **Item Alignment** compares the current-row and selected-item modes of ValueMenu.
- **Trigger Variants** compares ellipsis/text/icon action buttons and
  default/compact value selectors and selectors with icon or text prefixes.
- **Inside Dialog** shows both menus remaining interactive in a native dialog.

**Features** provides focused cases for disabled triggers, compact typography,
the animated Stipple backdrop, groups, disabled items, group/item icons and long
lists, including their searchable variants. Both menus use the same item labels,
icons, availability and selected value. Choosing an action or value updates both.
This keeps the common examples symmetric without implying that search or
group-title icons exist in ActionMenu.

**Features → Stipple Backdrop** is the single background/blur and typography
comparison. Both menus sit over the moving dots and inherit their trigger's
monospace font. Switch the Storybook theme to compare dark and light surfaces.

## Custom overlays

`MenuSurface`, `MenuScrollArea` and the row parts are exported for custom menus. Supply an `anchor` element,
position the surface with its div props/ref, and implement the appropriate
accessibility, focus and dismissal behavior. It portals into the anchor's
nearest open native dialog, or the document body otherwise, so menus remain in
the dialog's top layer. Inline typography styles can override the copied trigger
styles. Compose `MenuItem` with an `icon` and optional `trailing` content,
`MenuGroupLabel` for a section title and `MenuDivider` between groups. MenuItem
forwards Button props, refs and native events. These parts provide appearance;
the consumer supplies filtering, roles, keyboard behavior and selection.
MenuScrollArea accepts ScrollArea props, including `viewportRef` and slot classes.

Entrance transforms should release their animation state on completion. Check
settled menu edges using rendered pixels at fractional zoom as well as DOM
bounds: equal layout gaps can still paint differently in a retained animation.
