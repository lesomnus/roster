import { createContext, useContext, useMemo, type ReactNode } from "react";

export type UIMessage =
  | "Daily activity"
  | "Activity intensity"
  | "Less"
  | "More"
  | "Search"
  | "Search options"
  | "Search results"
  | "Close search"
  | "Result {current} of {count}"
  | "Image preview"
  | "Drag to move the image when zoomed in."
  | "Loading image…"
  | "The image could not be loaded."
  | "Image zoom"
  | "Choose date"
  | "Calendar for {label}"
  | "Previous month"
  | "Next month"
  | "Today"
  | "Clear date"
  | "Done"
  | "{count} selected"
  | "Choose a start date"
  | "Choose an end date"
  | "This selection is unavailable."
  | "Search {label}"
  | "Scroll {label} choices"
  | "Scroll {label}"
  | "No matches"
  | "Cancel"
  | "Confirm"
  | "Working…"
  | "Action failed"
  | "Dismiss error"
  | "Action failed. Please try again."
  | "Retry"
  | "Edit {label}"
  | "{label} choices"
  | "Inherited: {value}"
  | "Reset to inherited value"
  | "Terminal {number}"
  | "Terminal tabs"
  | "Close {name}"
  | "New terminal"
  | "Hide terminal"
  | "Workspace terminal"
  | "Resize terminal"
  | "Resize panes"
  | "Reconnect"
  | "Copied"
  | "Copy"
  | "About {label}"
  | "Copy failed"
  | "Clipboard access failed. Use the terminal context menu to copy.";
export type UITranslate = (
  message: UIMessage,
  values?: Record<string, string | number>,
) => string;
const english: UITranslate = (message, values = {}) =>
  message.replace(/\{(\w+)\}/g, (match, key) => String(values[key] ?? match));
const UIContext = createContext<{ t: UITranslate; locale?: string }>({
  t: english,
});

// Optional: components work with English defaults without a provider or app store.
export function UIProvider({
  translate = english,
  locale,
  children,
}: {
  translate?: UITranslate;
  locale?: string;
  children: ReactNode;
}) {
  const value = useMemo(() => ({ t: translate, locale }), [translate, locale]);
  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
}
export function useUI() {
  return useContext(UIContext);
}
