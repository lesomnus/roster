import { InkSparkle } from "../ink-sparkle/ink-sparkle";
import styles from "./switch.module.css";

export function Switch({
  label,
  checked,
  variant = "default",
  disabled = false,
  pending = false,
  onChange,
}: {
  label: string;
  checked: boolean;
  /** Compact fits beside body text; default preserves the standard control size. */
  variant?: "default" | "compact";
  disabled?: boolean;
  /** Keep checked at the current value while its opposite is being applied. */
  pending?: boolean;
  onChange: (checked: boolean) => void;
}) {
  const compact = variant === "compact";
  const width = compact ? 28 : 40;
  const height = compact ? 16 : 22;
  return (
    <button
      type="button"
      role="switch"
      aria-label={label}
      aria-checked={checked}
      aria-busy={pending || undefined}
      aria-disabled={pending || undefined}
      data-pending={pending || undefined}
      data-variant={variant}
      disabled={disabled}
      className={styles.switch_control}
      onClick={() => {
        if (!pending) onChange(!checked);
      }}
    >
      {/* A shared viewport avoids HTML thumb-box rounding at fractional scales. */}
      <svg
        className={styles.thumb_layer}
        viewBox={`0 0 ${width} ${height}`}
        aria-hidden="true"
      >
        <circle
          className={styles.thumb}
          data-switch-thumb=""
          cx={height / 2}
          cy={height / 2}
          r={compact ? 6 : 8}
        />
      </svg>
      {pending && (
        <InkSparkle
          className={styles.ink_sparkle}
          origin={[checked ? width + 8 : -8, height / 2]}
          centerMotion="fixed"
          duration={2000}
          loop
          color={checked ? [0, 0, 0, 0.5] : [1, 1, 1, 0.2]}
        />
      )}
    </button>
  );
}
