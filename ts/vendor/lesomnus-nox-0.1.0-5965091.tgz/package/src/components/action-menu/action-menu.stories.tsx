import { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { ActionMenu, Button } from "@lesomnus/nox";

const meta = {
  title: "Components/ActionMenu",
  component: ActionMenu,
  tags: ["autodocs"],
  parameters: {
    docs: {
      description: {
        component:
          "A menu beside its trigger, used for commands and checked choices. Menus reveal from the trigger-facing edge by default; set motion={false} to disable the entrance. This page keeps the basic API and an action-driven trigger example. Shared feature comparisons live under Menus/Features; placement, motion, shortcut labels and dangerous actions are demonstrated in the top-level Menus gallery.",
      },
    },
  },
  args: {
    label: "More",
    items: [
      { label: "Details", run: () => {} },
      { label: "Restart", run: () => {} },
      { label: "Stop", danger: true, run: () => {} },
    ],
  },
} satisfies Meta<typeof ActionMenu>;
export default meta;
type Story = StoryObj<typeof meta>;

export const More: Story = {};
export const Controlled: Story = {
  render: function Controlled(args) {
    const [open, setOpen] = useState(false);
    return (
      <>
        <Button onClick={() => setOpen(true)}>Open menu</Button>
        <ActionMenu {...args} open={open} onOpenChange={setOpen} />
      </>
    );
  },
};
export const RowActions: Story = {
  render: function RowActions() {
    const [last, setLast] = useState("None");
    return (
      <>
        <ActionMenu
          label="Row actions"
          footer={<span>Fixed footer</span>}
          groups={[
            {
              label: "Controls",
              layout: "row",
              items: [
                {
                  label: "Stop",
                  icon: <span>□</span>,
                  run: () => setLast("Stop"),
                },
                {
                  label: "Restart",
                  icon: <span>↻</span>,
                  disabled: true,
                  run: () => setLast("Restart"),
                },
                {
                  label: "Fork",
                  icon: <span>⑂</span>,
                  run: () => setLast("Fork"),
                },
              ],
            },
            {
              label: "Other actions",
              items: Array.from({ length: 24 }, (_, index) => ({
                label: `Action ${index + 1}`,
                run: () => setLast(`Action ${index + 1}`),
              })),
            },
          ]}
        />
        <output>{last}</output>
      </>
    );
  },
};
export const Language: Story = {
  args: { label: "Voice language" },
  render: function LanguageMenu(args) {
    const [language, setLanguage] = useState("English (US)");
    return (
      <ActionMenu
        {...args}
        triggerContent={language}
        items={["English (US)", "한국어", "日本語"].map((label) => ({
          label,
          checked: label === language,
          run: () => setLanguage(label),
        }))}
      />
    );
  },
  decorators: [
    (Story) => (
      <div style={{ width: 180 }}>
        <Story />
      </div>
    ),
  ],
};

export const OutsideScrollbar: Story = {
  args: {
    label: "Scrollable actions",
    placement: "above",
    scrollbarOffset: -12,
    motion: { from: "bottom-right", effect: "reveal" },
    footer: <Button>Keep menu open</Button>,
    items: Array.from({ length: 30 }, (_, i) => ({
      label: `Action ${i + 1}`,
      run: () => {},
    })),
  },
  decorators: [
    (Story) => (
      <div style={{ position: "fixed", bottom: 8, right: 4 }}>
        <Story />
      </div>
    ),
  ],
};
