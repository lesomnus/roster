export type TextMotion = "none" | "slide" | "flip";
export type TextDirection = "auto" | "up" | "down";
export type TextFlipEasing = "ease-in-out" | "linear";

export type TextCharacterDelayContext = {
  character: string;
  previousCharacter: string;
  /** Position in the complete new text, measured in Unicode code points. */
  index: number;
  length: number;
  /** Position among changed, animated characters only. */
  changedIndex: number;
  changedCount: number;
  text: string;
  previousText: string;
};

/** A stagger interval, or a callback returning an absolute start delay in ms. */
export type TextCharacterDelay =
  | number
  | ((context: TextCharacterDelayContext) => number);

export type TextMotionOptions = {
  motion?: TextMotion;
  /** Reveal a first mounted value from blank cells. */
  animateInitial?: boolean;
  /** Evaluated at each value change; false commits the value without motion. */
  shouldAnimate?: (element: HTMLElement) => boolean;
  /** Auto moves increasing values down and decreasing values up. */
  direction?: TextDirection;
  /** Each character's transition duration in milliseconds, excluding its start delay. */
  duration?: number;
  /** Stagger changed characters by this interval, or compute each start delay in ms. */
  characterDelay?: TextCharacterDelay;
  /** Maximum slides per changed digit, including the final landing. Defaults to 1. */
  maxSlideSteps?: number;
  /** Maximum flips per changed character within duration, including the final flip. */
  maxFlipSteps?: number;
  /** Sequence cadence: accelerate then decelerate (default), or keep every flip equal. */
  flipEasing?: TextFlipEasing;
  /** Ordered cyclic characters for intermediate flips. Defaults to digits or same-case Latin letters. */
  flipCharacters?: string;
};

/** Equal card distances along a sine ease-in-out progress curve, inverted to time. */
export function flipStepTimings(
  steps: number,
  duration: number,
  easing: TextFlipEasing = "ease-in-out",
): { start: number; duration: number }[] {
  const timeAt = (boundary: number) => {
    if (boundary === 0) return 0;
    if (boundary === steps) return duration;
    const progress = boundary / steps;
    return (
      duration *
      (easing === "linear" ? progress : Math.acos(1 - 2 * progress) / Math.PI)
    );
  };
  return Array.from({ length: steps }, (_, index) => {
    const start = timeAt(index);
    return { start, duration: timeAt(index + 1) - start };
  });
}

export function isFlipCharacter(
  character: string,
  characters?: string,
): boolean {
  return /[\p{L}\p{N}]/u.test(character) || !!characters?.includes(character);
}

/** Evaluate once per update so random callbacks remain stable throughout a transition. */
export function characterDelays(
  previousText: string,
  text: string,
  motion: TextMotion,
  delay: TextCharacterDelay = 0,
  flipCharacters?: string,
): number[] {
  const previous = Array.from(previousText);
  const next = Array.from(text);
  const changed = next.flatMap((character, index) =>
    motion !== "none" &&
    (previous[index] !== undefined || motion === "slide") &&
    previous[index] !== character &&
    (motion === "slide" || isFlipCharacter(character, flipCharacters))
      ? [index]
      : [],
  );
  const delays = next.map(() => 0);
  changed.forEach((index, changedIndex) => {
    const milliseconds =
      typeof delay === "number"
        ? delay * changedIndex
        : delay({
            character: next[index],
            previousCharacter: previous[index] ?? "",
            index,
            length: next.length,
            changedIndex,
            changedCount: changed.length,
            text,
            previousText,
          });
    delays[index] = Number.isFinite(milliseconds)
      ? Math.max(0, milliseconds)
      : 0;
  });
  return delays;
}

const characterGroups = [
  "0123456789",
  "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
  "abcdefghijklmnopqrstuvwxyz",
];

/** Digits share a bounded travel time; an unknown digit starts by revealing zero. */
export function slidePath(
  previous: string,
  next: string,
  direction: "up" | "down",
  maxSteps = 1,
): string[] {
  if (previous === next) return [];
  const limit = Number.isFinite(maxSteps)
    ? Math.max(1, Math.floor(maxSteps))
    : 1;
  if (limit === 1 || !/^[0-9]$/.test(next)) return [next];
  if (/^[0-9]$/.test(previous))
    return flipPath(previous, next, direction, limit, "0123456789");
  const target = Number(next);
  const steps = Math.min(limit - 1, target);
  return [
    "0",
    ...Array.from({ length: steps }, (_, index) =>
      String(Math.ceil((target * (index + 1)) / steps)),
    ),
  ];
}

/** Sample a bounded path through a cyclic character sequence, always landing on next. */
export function flipPath(
  previous: string,
  next: string,
  direction: "up" | "down",
  maxSteps = 1,
  characters?: string,
): string[] {
  if (previous === next) return [];
  const sequence = Array.from(
    new Set(
      Array.from(
        characters ??
          characterGroups.find(
            (group) => group.includes(previous) && group.includes(next),
          ) ??
          "",
      ),
    ),
  );
  const before = sequence.indexOf(previous);
  const after = sequence.indexOf(next);
  if (before < 0 || after < 0) return [next];
  const sign = direction === "down" ? 1 : -1;
  const distance =
    ((after - before) * sign + sequence.length) % sequence.length;
  const steps = Math.min(
    distance,
    Number.isFinite(maxSteps) ? Math.max(1, Math.floor(maxSteps)) : 1,
  );
  return Array.from({ length: steps }, (_, index) => {
    const offset = Math.ceil((distance * (index + 1)) / steps);
    return sequence[
      (before + sign * offset + sequence.length) % sequence.length
    ];
  });
}

export function textDirection(
  direction: TextDirection,
  previous: string,
  next: string,
  previousOrder?: number,
  nextOrder?: number,
): "up" | "down" {
  if (direction !== "auto") return direction;
  const before = previousOrder ?? Number(previous);
  const after = nextOrder ?? Number(next);
  const difference =
    Number.isFinite(before) && Number.isFinite(after)
      ? after - before
      : next.localeCompare(previous, undefined, { numeric: true });
  return difference < 0 ? "up" : "down";
}
