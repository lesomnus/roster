export type RelativeTimeFormatOptions = {
  /** Use locale-aware narrow units, e.g. "5m ago" / "in 2h" in English. */
  compact?: boolean;
};

export function formatRelativeDateTime(
  date: Date,
  locale: string,
  now = Date.now(),
  { compact = false }: RelativeTimeFormatOptions = {},
) {
  const elapsed = date.getTime() - now;
  const format = new Intl.RelativeTimeFormat(locale, {
    numeric: compact ? "always" : "auto",
    style: compact ? "narrow" : "long",
  });
  const units = [
    [365 * 86400000, "year"],
    [30 * 86400000, "month"],
    [7 * 86400000, "week"],
    [86400000, "day"],
    [3600000, "hour"],
    [60000, "minute"],
  ] as const;
  for (const [duration, unit] of units) {
    if (Math.abs(elapsed) >= duration)
      return format.format(Math.trunc(elapsed / duration), unit);
  }
  return new Intl.RelativeTimeFormat(locale, {
    numeric: "auto",
    style: compact ? "narrow" : "long",
  }).format(0, "second");
}

export function formatLocalDateTime(date: Date) {
  const pad = (value: number) => String(value).padStart(2, "0");
  return (
    `${String(date.getFullYear()).padStart(4, "0")}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}` +
    `T${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`
  );
}

export function formatOffsetDateTime(date: Date) {
  const pad = (value: number) => String(value).padStart(2, "0");
  const offset = -date.getTimezoneOffset();
  const magnitude = Math.abs(offset);
  return (
    formatLocalDateTime(date) +
    `${offset < 0 ? "-" : "+"}${pad(Math.floor(magnitude / 60))}:${pad(magnitude % 60)}`
  );
}
