import {
  useEffect,
  useState,
  type HTMLAttributes,
  type ReactNode,
} from "react";
import { useUI } from "../../providers/ui-provider";
import {
  formatOffsetDateTime,
  formatLocalDateTime,
  formatRelativeDateTime,
  type RelativeTimeFormatOptions,
} from "./date-time-format";
import styles from "./date-time.module.css";
import {
  AnimatedText,
  type TextMotionOptions,
} from "../animated-text/animated-text";

export type DateTimeProps = Omit<HTMLAttributes<HTMLTimeElement>, "children"> &
  TextMotionOptions & {
    value?: Date | number | string | null;
    /** Custom fallback for missing or invalid values. */
    empty?: ReactNode;
    showOffset?: boolean;
  };

export function DateTime({
  value,
  empty,
  showOffset = true,
  className = "",
  motion = "none",
  direction,
  duration,
  characterDelay,
  animateInitial,
  shouldAnimate,
  maxSlideSteps,
  maxFlipSteps,
  flipEasing,
  flipCharacters,
  ...props
}: DateTimeProps) {
  const date =
    value == null ? undefined : value instanceof Date ? value : new Date(value);
  const validDate = date && Number.isFinite(date.getTime()) ? date : undefined;
  if (!validDate && empty !== undefined) return <>{empty}</>;
  const text = validDate
    ? showOffset
      ? formatOffsetDateTime(validDate)
      : formatLocalDateTime(validDate)
    : showOffset
      ? "0000-00-00T00:00:00+00:00"
      : "0000-00-00T00:00:00";
  const content = validDate ? (
    <AnimatedText
      value={text}
      comparisonValue={validDate.getTime()}
      motion={motion}
      direction={direction}
      duration={duration}
      characterDelay={characterDelay}
      animateInitial={animateInitial}
      shouldAnimate={shouldAnimate}
      maxSlideSteps={maxSlideSteps}
      maxFlipSteps={maxFlipSteps}
      flipEasing={flipEasing}
      flipCharacters={flipCharacters}
      characterClassName={(character) =>
        /\D/.test(character) ? styles.separator : undefined
      }
    />
  ) : (
    text.split(/(\D+)/).map((part, index) =>
      /\D/.test(part) ? (
        <span key={index} className={styles.separator}>
          {part}
        </span>
      ) : (
        <span key={index}>
          {Array.from(part, (_, digit) => (
            <span key={digit} className={styles.placeholder}>
              {value == null ? "·" : "x"}
            </span>
          ))}
        </span>
      ),
    )
  );
  if (!validDate)
    return (
      <span
        {...props}
        className={`${styles.time} ${className}`}
        role={props.role ?? "img"}
        aria-label={
          props["aria-label"] ??
          (value == null ? "Date unavailable" : "Invalid date")
        }
      >
        {content}
      </span>
    );
  return (
    <time
      {...props}
      className={`${styles.time} ${className}`}
      dateTime={validDate.toISOString()}
    >
      {content}
    </time>
  );
}

export {
  formatOffsetDateTime,
  formatLocalDateTime,
  formatRelativeDateTime,
} from "./date-time-format";
export type { RelativeTimeFormatOptions } from "./date-time-format";
export type RelativeTimeProps = Omit<
  HTMLAttributes<HTMLTimeElement>,
  "children"
> &
  RelativeTimeFormatOptions & {
    value?: Date | number | string | null;
    now?: number;
    locale?: string;
    interval?: number;
  };
export function RelativeTime({
  value,
  now,
  locale: preferredLocale,
  interval = 30000,
  compact = false,
  className = "",
  ...props
}: RelativeTimeProps) {
  const ui = useUI();
  const locale = preferredLocale ?? ui.locale ?? "en";
  const [clock, setClock] = useState(Date.now);
  const date =
    value == null ? undefined : value instanceof Date ? value : new Date(value);
  const valid = date && Number.isFinite(date.getTime());
  useEffect(() => {
    if (!valid || now !== undefined) return;
    setClock(Date.now());
    const timer = setInterval(
      () => {
        if (!document.hidden) setClock(Date.now());
      },
      Math.max(1000, interval),
    );
    return () => clearInterval(timer);
  }, [valid, now, interval]);
  if (!valid) return null;
  return (
    <time
      {...props}
      className={`${styles.time} ${className}`}
      dateTime={date.toISOString()}
    >
      {formatRelativeDateTime(date, locale, now ?? clock, { compact })}
    </time>
  );
}
